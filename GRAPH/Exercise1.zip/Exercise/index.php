<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grafico de los lenguajes Backend mas usados</title>
</head>
<body>
    <h1>Lenguajes de Backend mas Utilizados en los ultimos 10 años</h1>

    <img src="Backend_languages.php" alt="Grafico de lenguajes backend">

    <hr>
    
</body>
</html>